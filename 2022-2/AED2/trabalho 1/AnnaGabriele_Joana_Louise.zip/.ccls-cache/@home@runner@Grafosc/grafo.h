typedef struct grafo Grafo;
