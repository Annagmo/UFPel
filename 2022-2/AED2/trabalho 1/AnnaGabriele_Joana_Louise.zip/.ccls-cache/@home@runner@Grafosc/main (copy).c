/* Protótipo do que eu acho que seria o código:
x |v1|v2
v1|p1|p2
v2|- |p3
*/
#include <stdio.h>
#include <stdlib.h>

#define maxV 20

int grafo[maxV][maxV];

int main() {
  int opcao, numV;
  printf("\n Bem-vindo ao gerador de grafos!\n");

  do { //repita quando numV for maior q 20
    printf("Entre com a quantidade de vértices: ");
    scanf("%d", &numV);
  } while (numV > 20); // <= 20

  printf("\t1 p/ Adicionar aresta.\n");
  printf("\t2 p/ Listar grafo.\n");
  printf("\t3 p/ Sair.\n");

  printf("Entre opção desejada: ");
  scanf("%d", &opcao);

  switch (opcao) {
  case 1:
   addAresta(numV); // (add o peso ba aresta cujos vértices o usuário que vai dizer, e retorna a aresta pro gráfico global)
  case 2:
  listaGrafo(numV); // (roda a matriz imprimindo)
  case 3:
    break;

  default:
    printf("\n\nOPCAO INVALIDA!\n");
    break;
  }
  return 0;
}

//int addAresta(int numV){}


//void listaGrafo(int numV){}