#include <stdio.h>
#include <stdlib.h>

#define maxV 20
int grafo[maxV][maxV];

int main() {
  int opcao, numV, resposta = 0;
  printf("\n Bem-vindo ao gerador de grafos!\n");
  
  do {
    printf("Entre com a quantidade de vértices: ");
    scanf("%d", &numV);
  } while (numV > 20);
  

  do{
    printf("\n\tMenu:\n");
    printf("\t1 p/ Adicionar aresta.\n");
    printf("\t2 p/ Listar grafo.\n");
    printf("\t3 p/ Sair.\n");
  
    printf("Entre opção desejada: ");
    scanf("%d", &opcao);
  
    switch (opcao) {
    case 1:
      addAresta(numV);  
      break;
      
    case 2:
      listaGrafo(numV); 
      break;
      
    case 3:
      resposta = acabou(); 
      break;
      
    default:
      printf("\n\nOPCAO INVALIDA!\n");
      break;
    }
  }while(resposta!=1);
  
  return 0;
}

int addAresta(int numeroDeVertices){
    int vertice1, vertice2;
    int pesoAresta;

    do{
        printf("Insira o primeiro vértice: ");
        scanf("%d", &vertice1);

        printf("Insira o segundo vértice: ");
        scanf("%d", &vertice2);

        vertice1--;vertice2--;
        
    } while ((vertice1 < 0 || vertice1 >= numeroDeVertices) && (vertice2 < 0 || vertice2 >= numeroDeVertices));

    
    printf("Qual o peso da Aresta digitada?\n");
    scanf("%d", &pesoAresta);

    while (pesoAresta < 0){
    printf("O peso não deve ser menor que 0.\n");
    printf("Qual o peso da Aresta digitada?\n");
    scanf("%d", &pesoAresta);
    }    
    grafo[vertice1][vertice2] = pesoAresta;

    return grafo;
}

int listaGrafo(int numeroDeVertices){
    int i,j;

     for (i = 0; i < numeroDeVertices; i++){
        for (j = 0; j <numeroDeVertices; j++){
            printf("%d ", grafo[i][j]);
        }
        printf("\n");
      }
  return 0;
}

int acabou(){
  int resposta;
  printf("\nAcabou de digitar as arestas?.\n");

  printf("Digite 1 para sim.\n");
  scanf("%d", &resposta);

  return resposta;
}